# Campus Parking System — Project Report

**Author:** Swar Sawalkar  
**Date:** <insert date>  
**Course / Project:** Campus Parking System — College Project

---

## 1. Abstract
The Campus Parking System is a lightweight web application that streamlines the management of vehicle parking on campus. It provides a central interface for users to register vehicles, view allocated parking slots, and for administrators to manage parking records. The system is designed for small-to-medium size campuses, offering an extendable architecture for future enhancements such as automated slot allocation, authentication, reporting, and live monitoring.

---

## 2. Objectives
- Provide a simple and intuitive UI for parking registration and queries.  
- Store and retrieve vehicle parking data reliably using a lightweight database.  
- Separate frontend and backend responsibilities to allow independent development and deployment.  
- Provide APIs that can be extended for administrative tasks and analytics.

---

## 3. Scope
The initial implementation includes:
- Static frontend (HTML/CSS) for UI forms and pages.  
- Flask backend with RESTful endpoints for registration, retrieval, and deletion.  
- SQLite database for local storage (easy to deploy and maintain).  
- Authentication module to manage users and admin privileges (optional but included).

---

## 4. System Architecture
**Components:**
1. **Frontend** — Static HTML/CSS pages for users.  
2. **Backend** — Python Flask application exposing REST endpoints.  
3. **Database** — SQLite (serverless, file-based DB).  
4. **Session Management** — Flask session cookie for authentication.

**Data Flow:**  
User (browser) → Frontend UI → HTTP Request → Flask Backend → SQLite → Response → Frontend.

---

## 5. Database Schema
**Table: users**
- `id` INTEGER PRIMARY KEY AUTOINCREMENT  
- `username` TEXT UNIQUE  
- `password_hash` TEXT  
- `email` TEXT  
- `is_admin` INTEGER (0/1)

**Table: parking**
- `id` INTEGER PRIMARY KEY AUTOINCREMENT  
- `name` TEXT  
- `vehicle_no` TEXT  
- `slot` TEXT

---

## 6. API Endpoints (Summary)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST   | `/auth/register` | Register a new user: `{username,password,email?}` |
| POST   | `/auth/login` | Login user, returns session cookie |
| POST   | `/auth/logout` | Logout user, clears session |
| GET    | `/auth/me` | Returns current session user info |
| POST   | `/parking/register` or `/park` | Register a vehicle `{name,vehicle_no,slot}` |
| GET    | `/parking` or `/vehicles` | Get all vehicles |
| DELETE | `/parking/<id>` or `/exit/<vehicle_no>` | Delete parking entry |

> Replace or extend endpoint paths as per your backend file naming.

---

## 7. Implementation Details

### 7.1 Backend
- Implemented with Flask.  
- Uses `sqlite3` for database operations and `werkzeug.security` for password hashing.  
- Blueprints separate authentication logic (`auth.py`) and main parking logic (`app.py` or other controllers).

### 7.2 Frontend
- Static pages built with semantic HTML and CSS.  
- JavaScript `fetch()` calls to backend APIs.

### 7.3 Security
- Passwords are stored hashed (PBKDF2 via Werkzeug).  
- Sessions use Flask's signed cookies; `secret_key` must be kept secure.  
- For production, use HTTPS and environment variables for secrets.

---

## 8. Testing Strategy
- **Unit Tests** for database functions (create/read/update/delete) — recommended using `pytest`.  
- **Integration Tests** to validate API endpoints using `Flask` test client.  
- **Manual Testing** for UI flows: registration, login, vehicle registration, and deletion.

---

## 9. Deployment Plan
1. Host frontend on **GitHub Pages** for static UI.  
2. Host Flask backend on **Render** or **Railway** (free tiers available) or deploy to **Google Cloud Run** for production.  
3. Set up environment variables for DB and secret key.  
4. Use persistent DB (MySQL or PostgreSQL) for production instead of SQLite.

---

## 10. Future Work & Enhancements
- Implement role-based admin dashboard.  
- Add booking & slot auto-allocation algorithms.  
- Integrate real-time occupancy updates via WebSocket.  
- Add reporting & analytics (daily/weekly/monthly).  
- Containerize using Docker for consistent deployment.

---

## 11. Conclusion
The Campus Parking System serves as a functional prototype for campus parking management. It demonstrates clean separation between frontend and backend and provides a solid foundation to add more advanced features like authentication, slot-booking logic, and analytics.

---

## 12. References
- Flask official docs — https://flask.palletsprojects.com  
- SQLite — https://www.sqlite.org/  
- Werkzeug security — https://werkzeug.palletsprojects.com

---
